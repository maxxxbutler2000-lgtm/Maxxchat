# Maxxchat for Netlify

This folder is ready to deploy to Netlify.

## Deploy

1. Deploy this `netlify-deploy` folder as the Netlify project root.
2. Do not use a plain static drag-and-drop upload unless Netlify also builds the functions. The chat needs Netlify Functions.
3. Easiest options:
   - connect a GitHub repo and set the base directory to `netlify-deploy`
   - or run Netlify CLI from inside this folder
4. Netlify will publish `public` and deploy the functions.
5. Open the Netlify URL, create a room, and share the room code.

## Quick Check

After deploy, open this URL on your Netlify site:

```text
https://YOUR-SITE.netlify.app/api/room?code=TEST
```

If you see JSON with `No room found for that code.`, the backend function is installed. If you see a Netlify 404 page, the site was deployed as static-only and the functions were not included.

## Note

The local app uses an always-running Node server. Netlify uses serverless functions, so this deploy version refreshes messages every couple of seconds.

This version can use Netlify Blobs if that package is installed by your deployment, but it also includes a no-dependency fallback so the room-creation button does not crash with a 502 if Blobs is unavailable.
