const crypto = require("crypto");

const memoryRooms = globalThis.__maxxchatMemoryRooms || new Map();
globalThis.__maxxchatMemoryRooms = memoryRooms;
let blobStore;
let blobStoreUnavailable = false;

function getRoomStore() {
  if (blobStoreUnavailable) return null;
  if (blobStore) return blobStore;
  try {
    const { getStore } = require("@netlify/blobs");
    blobStore = getStore("maxxchat-rooms");
    return blobStore;
  } catch (error) {
    blobStoreUnavailable = true;
    return null;
  }
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    },
    body: JSON.stringify(body)
  };
}

function cleanName(value) {
  const fallback = `Guest ${Math.floor(100 + Math.random() * 900)}`;
  return String(value || fallback).trim().replace(/\s+/g, " ").slice(0, 28) || fallback;
}

function cleanRoomCode(value) {
  return String(value || "").trim().toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
}

function cleanMessage(value) {
  return String(value || "").replace(/\s+$/g, "").slice(0, 800);
}

function makeRoomCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i += 1) {
    code += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return code;
}

function makeUser(name) {
  return {
    id: crypto.randomUUID(),
    name: cleanName(name),
    color: `hsl(${Math.floor(Math.random() * 360)} 72% 48%)`,
    joinedAt: Date.now()
  };
}

function systemMessage(text) {
  return {
    id: crypto.randomUUID(),
    type: "system",
    text,
    createdAt: Date.now()
  };
}

function roomPayload(room) {
  return {
    code: room.code,
    users: room.users,
    messages: room.messages.slice(-80),
    typing: room.typing.map((item) => item.name)
  };
}

async function readRoom(code) {
  const cleanCode = cleanRoomCode(code);
  const store = getRoomStore();
  if (!store) return memoryRooms.get(cleanCode) || null;
  return store.get(cleanCode, { type: "json" });
}

async function writeRoom(room) {
  room.lastActivity = Date.now();
  const store = getRoomStore();
  if (!store) {
    memoryRooms.set(room.code, room);
    return;
  }
  await store.setJSON(room.code, room);
}

function bodyFrom(event) {
  try {
    return event.body ? JSON.parse(event.body) : {};
  } catch (error) {
    return {};
  }
}

async function createRoom(body) {
  let code = makeRoomCode();
  for (let i = 0; i < 8 && await readRoom(code); i += 1) {
    code = makeRoomCode();
  }
  const user = makeUser(body.name);
  const room = {
    code,
    users: [user],
    messages: [systemMessage(`${user.name} created the room.`)],
    typing: [],
    createdAt: Date.now(),
    lastActivity: Date.now()
  };
  await writeRoom(room);
  return json(201, { room: roomPayload(room), user });
}

async function joinRoom(body) {
  const room = await readRoom(body.code);
  if (!room) return json(404, { error: "No room found for that code." });
  const user = makeUser(body.name);
  room.users.push(user);
  room.messages.push(systemMessage(`${user.name} joined.`));
  room.messages = room.messages.slice(-160);
  await writeRoom(room);
  return json(200, { room: roomPayload(room), user });
}

async function getRoom(event) {
  const room = await readRoom(event.queryStringParameters && event.queryStringParameters.code);
  if (!room) return json(404, { error: "No room found for that code." });
  const activeBefore = Date.now() - 5000;
  room.typing = room.typing.filter((item) => item.updatedAt > activeBefore);
  await writeRoom(room);
  return json(200, { room: roomPayload(room) });
}

async function sendMessage(body) {
  const room = await readRoom(body.code);
  const user = room && room.users.find((item) => item.id === body.userId);
  const text = cleanMessage(body.text);
  if (!room || !user) return json(404, { error: "Room or user not found." });
  if (!text) return json(400, { error: "Message cannot be empty." });

  room.typing = room.typing.filter((item) => item.userId !== user.id);
  room.messages.push({
    id: crypto.randomUUID(),
    type: "chat",
    text,
    userId: user.id,
    userName: user.name,
    color: user.color,
    createdAt: Date.now()
  });
  room.messages = room.messages.slice(-160);
  await writeRoom(room);
  return json(201, { ok: true });
}

async function setTyping(body) {
  const room = await readRoom(body.code);
  const user = room && room.users.find((item) => item.id === body.userId);
  if (!room || !user) return json(404, { error: "Room or user not found." });
  room.typing = room.typing.filter((item) => item.userId !== user.id);
  if (body.isTyping) {
    room.typing.push({ userId: user.id, name: user.name, updatedAt: Date.now() });
  }
  await writeRoom(room);
  return json(200, { ok: true });
}

async function leaveRoom(body) {
  const room = await readRoom(body.code);
  if (!room) return json(200, { ok: true });
  const user = room.users.find((item) => item.id === body.userId);
  room.users = room.users.filter((item) => item.id !== body.userId);
  room.typing = room.typing.filter((item) => item.userId !== body.userId);
  if (user) room.messages.push(systemMessage(`${user.name} left.`));
  room.messages = room.messages.slice(-160);
  await writeRoom(room);
  return json(200, { ok: true });
}

exports.handler = async (event) => {
  try {
    const endpoint = event.path.replace(/^\/api\/?/, "").replace(/^\/\.netlify\/functions\/api\/?/, "");
    const body = bodyFrom(event);

    if (event.httpMethod === "POST" && endpoint === "rooms") return createRoom(body);
    if (event.httpMethod === "POST" && endpoint === "join") return joinRoom(body);
    if (event.httpMethod === "GET" && endpoint === "room") return getRoom(event);
    if (event.httpMethod === "POST" && endpoint === "messages") return sendMessage(body);
    if (event.httpMethod === "POST" && endpoint === "typing") return setTyping(body);
    if (event.httpMethod === "POST" && endpoint === "leave") return leaveRoom(body);

    return json(404, { error: "Not found." });
  } catch (error) {
    return json(500, {
      error: "The chat backend failed on Netlify. Check that this was deployed as a Netlify project with Functions enabled, not as a static-only upload."
    });
  }
};
